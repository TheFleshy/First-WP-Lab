package mk.ukim.finki.wp.june2025g1.model;

public enum Industry {
    FINTECH,
    AI,
    BIOTECH,
    CYBERSECURITY,
}
