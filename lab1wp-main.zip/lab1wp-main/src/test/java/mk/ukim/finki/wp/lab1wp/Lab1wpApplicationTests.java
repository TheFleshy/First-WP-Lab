package mk.ukim.finki.wp.lab1wp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab1wpApplicationTests {

    @Test
    void contextLoads() {
    }

}
